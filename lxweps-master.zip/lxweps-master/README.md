# lxweps
By default, players don't spawn with a large variety of weapons/tools. With this script, you can allow individual players to always spawn with weapons/tools of your choosing through the in-game menu.
